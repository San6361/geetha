<?php
if (isset($_POST['video_url'])) {
    $videoUrl = escapeshellarg($_POST['video_url']); // sanitize input

    // Output folder
    $outputDir = __DIR__ . "/downloads";
    if (!is_dir($outputDir)) {
        mkdir($outputDir, 0777, true);
    }

    // Run yt-dlp command
    $command = "yt-dlp -o '$outputDir/%(title)s.%(ext)s' $videoUrl 2>&1";
    exec($command, $output, $returnCode);

    if ($returnCode === 0) {
        // Find latest downloaded file
        $files = glob("$outputDir/*.*");
        $latestFile = end($files);

        if ($latestFile && file_exists($latestFile)) {
            $fileName = basename($latestFile);

            header("Content-Description: File Transfer");
            header("Content-Type: application/octet-stream");
            header("Content-Disposition: attachment; filename=\"$fileName\"");
            header("Content-Length: " . filesize($latestFile));
            flush();
            readfile($latestFile);

            unlink($latestFile); // delete after download
            exit;
        } else {
            echo "<p style='color:red;'>❌ File not found!</p>";
        }
    } else {
        echo "<p style='color:red;'>❌ Error running yt-dlp<br>" . implode("<br>", $output) . "</p>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Universal Video Downloader</title>
    <style>
        body { font-family: Arial; background:#111; color:white; text-align:center; padding:50px; }
        input { width:70%; padding:12px; border-radius:8px; border:none; }
        button { padding:12px 24px; border:none; border-radius:8px; background:#28a745; color:white; cursor:pointer; font-size:16px; }
        button:hover { background:#218838; }
        .box { background:#222; padding:30px; border-radius:12px; display:inline-block; }
    </style>
</head>
<body>
    <div class="box">
        <h2>🎥 Universal Video Downloader</h2>
        <form method="post">
            <input type="text" name="video_url" placeholder="Paste video link here..." required>
            <br><br>
            <button type="submit">Download Video</button>
        </form>
    </div>
</body>
</html>
